<?php
$dsn = 'mysql:host=localhost;dbname=doorprize';
$db = new PDO($dsn, 'root', 'root');
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);